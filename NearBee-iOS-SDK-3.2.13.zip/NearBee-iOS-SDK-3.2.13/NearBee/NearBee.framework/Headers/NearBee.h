//
//  NearBee.h
//  NearBee
//
//  Created by Amit Prabhu on 09/01/18.
//  Copyright © 2018 Amit Prabhu. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for NearBee.
FOUNDATION_EXPORT double NearBeeVersionNumber;

//! Project version string for NearBee.
FOUNDATION_EXPORT const unsigned char NearBeeVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <NearBee/PublicHeader.h>


