throw new Error('NPM Module \'nearbee-ios\' has no main JavaScript export.');
